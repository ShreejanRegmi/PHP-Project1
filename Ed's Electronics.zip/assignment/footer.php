		<footer> <!-- beginning of footer section -->
			&copy; Ed's Electronics 2018 
		</footer>
	</body>
</html> <!-- end of html -->
