<?php
//code of php is started
$pdo= new PDO('mysql:dbname=csy2028b; host=localhost', 'root', '');//variable of PDO class for connection to database
//end for code of php
?>